#ifndef GPSHelper_h
#define GPSHelper_h

#include <Arduino.h>
#include <HardwareSerial.h>
#include <TinyGPS++.h>
#include <math.h>

class GPSHelper {
  public:
    GPSHelper(int gps_rx_pin, int gps_tx_pin);
    void begin();
    bool fetch();
    float getLongitude();
    float getLatitude();
    float getAltitude();
    int getSatellites();
    float getAngle(float targetLat, float targetLong);

  private:
    HardwareSerial gpsSerial;
    TinyGPSPlus gps;
    float filteredLongitude = 0.0;
    float filteredLatitude = 0.0;
    bool isFirstReading = true;

    void getFilteredGPS(float& longitude, float& latitude);
    float calculateAngle(float targetLat, float targetLong, float currentLat, float currentLong);

    float longitude;
    float latitude;
    float altitude;
    int satellites;
};

#endif
