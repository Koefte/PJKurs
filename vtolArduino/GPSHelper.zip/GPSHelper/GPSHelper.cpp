#include "GPSHelper.h"

GPSHelper::GPSHelper(int gps_rx_pin, int gps_tx_pin) : gpsSerial(1) {
  gpsSerial.begin(115200, SERIAL_8N1, gps_rx_pin, gps_tx_pin);
}

void GPSHelper::begin() {
  Serial.begin(9600);
  while (!Serial) {
    delay(10);
  }
}

bool GPSHelper::fetch() {
  while (gpsSerial.available()) {
    char c = gpsSerial.read();
    gps.encode(c);
  }

  if (gps.location.isUpdated() && gps.altitude.isUpdated() && gps.satellites.isUpdated()) {
    longitude = gps.location.lng();
    latitude = gps.location.lat();
    altitude = gps.altitude.meters();
    satellites = gps.satellites.value();
    return true;
  }

  return false;
}

float GPSHelper::getLongitude() {
  return longitude;
}

float GPSHelper::getLatitude() {
  return latitude;
}

float GPSHelper::getAltitude() {
  return altitude;
}

int GPSHelper::getSatellites() {
  return satellites;
}

float GPSHelper::getAngle(float tarLat, float tarLng) {
  getFilteredGPS(longitude, latitude);
  return calculateAngle(tarLat, tarLng, latitude, longitude);
}

void GPSHelper::getFilteredGPS(float& longitude, float& latitude) {
  while (gpsSerial.available()) {
    char c = gpsSerial.read();
    gps.encode(c);
  }

  if (gps.location.isUpdated() && gps.hdop.isValid() && gps.hdop.hdop() < 3) {
    if (isFirstReading) {
      filteredLongitude = gps.location.lng();
      filteredLatitude = gps.location.lat();
      isFirstReading = false;
    }
    
    filteredLongitude = 0.2 * gps.location.lng() + 0.8 * filteredLongitude;
    filteredLatitude = 0.2 * gps.location.lat() + 0.8 * filteredLatitude;
  }
  
  longitude = filteredLongitude;
  latitude = filteredLatitude;
}

float GPSHelper::calculateAngle(float targetLat, float targetLong, float currentLat, float currentLong) {
  float lat1Rad = radians(currentLat);
  float long1Rad = radians(currentLong);
  float lat2Rad = radians(targetLat);
  float long2Rad = radians(targetLong);
  float dLong = long2Rad - long1Rad;
  float angle = atan2(sin(dLong) * cos(lat2Rad), 
                      cos(lat1Rad) * sin(lat2Rad) - sin(lat1Rad) * cos(lat2Rad) * cos(dLong));
  angle = degrees(angle);
  angle = fmod(angle + 360, 360);
  return angle;
}
