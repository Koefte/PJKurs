#ifndef ListLibrary_h
#define ListLibrary_h

#include <Arduino.h>

template <class T>
class Node {
public:
    T data;
    Node* next;

    Node(T data) {
        this->data = data;
        this->next = NULL;
    }
};

template <class T>
class Verwaltung {
private:
    Node<T>* head;
    Node<T>* current;

public:
    Verwaltung() {
        head = NULL;
        current = NULL;
    }

    void addNode(T data) {
        Node<T>* newNode = new Node<T>(data);
        if (head == NULL) {
            head = newNode;
            current = newNode;
        } else {
            current->next = newNode;
            current = newNode;
        }
    }

    void deleteNode(Node<T>* nodeToDelete) {
        if (nodeToDelete == NULL) return;

        Node<T>* current = head;
        Node<T>* previous = NULL;

        while (current != NULL && current != nodeToDelete) {
            previous = current;
            current = current->next;
        }

        if (current == NULL) return;

        if (previous != NULL) {
            previous->next = current->next;
        } else {
            head = current->next;
        }

        delete current;
    }

    void goToFirstNode() {
        current = head;
    }

    void goToNextNode() {
        if (current != NULL) {
            current = current->next;
        }
    }

    T* getCurrentData() {
        if (current != NULL) {
            return &(current->data);
        }
        return NULL;
    }

    Node<T>* getCurrentNode() {
        return current;
    }
};

#endif
